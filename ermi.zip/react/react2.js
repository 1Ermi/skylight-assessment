import { motion } from 'framer-motion';

const messageVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
};

const ChatMessage = ({ message }) => {
  return (
    <motion.div variants={messageVariants} initial="hidden" animate="visible">
      {message.text}
    </motion.div>
  );
};